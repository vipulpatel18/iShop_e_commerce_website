import React from "react";

export default function mainImg() {
  return (
    <div
      style={{
        background:
          "linear-gradient(67deg, #E71D3A 0%, #ECC7C1 45%, #EFCAC4 58%, #E4BDB8 70%, #42A8FE 100%)",
      }}
      className="bg-no-repeat p-4 h-[463px] w-full"
    >
        <img src="img/2_corousel@2x.png" alt="" className="h-[447px] absolute right-36" />
    </div>
  );
}
