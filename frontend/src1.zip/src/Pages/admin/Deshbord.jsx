import React from "react";

export default function Deshbord() {
  return (
    <main className="flex-1 p-6">
      <h2 className="text-xl font-semibold mb-4">
        Welcome to the Admin Dashboard
      </h2>
      <p>Select an option from the menu to manage your application.</p>
    </main>
  );
}
